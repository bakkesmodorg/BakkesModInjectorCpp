NEW: Press F2 in-game to open the GUI.

To open console press the tilde key (`). You can change this using the cl_console_key cvar.
See cvars.txt for all commands & variables

BakkesMod is installed in:
[STEAMFOLDER]\steamapps\common\rocketleague\Binaries\Win32\bakkesmod\

Key presses (for binds) are case sensitive right now, please change your keybindings in the config.cfg. When you've done that, type exec config in the console and the changes will be applied.

Keybindings only work when console is closed.
https://wiki.unrealengine.com/List_of_Key/Gamepad_Input_Names

