from bakkesmod import Vector, Rotator
import math
from random import randint, choice

def vector_to_rotator(v):
	rot = Rotator()
	rot.yaw = math.atan2(v.y, v.x) * 10430.3783504704527
	rot.pitch = math.atan2(v.z, math.sqrt((v.x*v.x) + (v.y * v.y))) * 10430.3783504704527
	rot.roll = 0
	return rot
	
if game_wrapper.is_in_tutorial():
	tut = game_wrapper.get_game_event_as_tutorial()
	player = tut.get_game_car()
	ball = tut.get_ball()

	x_start = randint(500, 1200) if randint(0, 1) is 0 else -randint(500, 1200)
	ball_spawn = Vector(x_start, randint(-1700, 1700), 95)
	ball_spawn_norm = Vector(ball_spawn.x, ball_spawn.y, ball_spawn.z)
	ball_spawn_norm.normalize()
	y_diff = x_start*2 if randint(0,1) is 0 else -x_start*2
	car_spawn = ball_spawn - (ball_spawn_norm*Vector(500, 100, 0)) - Vector(0, max(-2000, min(y_diff, 2000)), 65)
	
	impact = ball_spawn - (ball_spawn_norm*Vector(500, 100, 0))
	
	ball.stop()
	player.stop()
	ball.set_location(ball_spawn)
	player.set_location(car_spawn)
	
	dist_to_ball = (ball_spawn - impact)
	dist_to_ball.normalize()
	car_rot = vector_to_rotator(dist_to_ball)
	player.set_rotation(car_rot)
	ball.set_velocity(dist_to_ball * Vector(2200, 1200, 0))
	player.set_velocity(dist_to_ball * Vector(1200, 1200, 0))
	
def shoot_ball():
	ball.set_velocity(ball_velocity)