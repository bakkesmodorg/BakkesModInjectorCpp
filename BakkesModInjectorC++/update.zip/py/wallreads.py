from bakkesmod import Vector, Rotator
import math
from random import randint, choice

ball_velocity = Vector(0)
reverse = (randint(0, 1) == 1)
if game_wrapper.is_in_tutorial():
	tut = game_wrapper.get_game_event_as_tutorial()
	player = tut.get_game_car()
	ball = tut.get_ball()

	ball_start = Vector(randint(-3071, -843), randint(514,3911), randint(100, 1700))
	
	player_start = Vector(randint(-3300, -400), randint(-2800, -900), 25)
	player_start_rot = Rotator(0, randint(12760, 20760), 0)
	player_start_vel = Vector(0, randint(800, 2100), 0)
	
	if reverse:
		ball_start.x = -ball_start.x 
		player_start.x = -player_start_vel.x 
		
	player.stop()
	player.set_location(player_start)
	player.set_rotation(player_start_rot)
	player.set_velocity(player_start_vel)
	ball.stop()
	ball.set_location(ball_start)
	
	#player_start_rot.yaw -= 32000
	#player_start_rot.Roll = 0
	
	dest = Vector(randint(-4071, -2200), randint(1381, 2502), randint(1250, 1616))
	if reverse:
		dest.x = -dest.x
	
	ball_velocity = tut.generate_shot(ball_start, dest, randint(1100, 1400))
	
	
	bakpy.set_timeout("shoot_ball", .3)
	
def shoot_ball():
	ball.set_velocity(ball_velocity)
	ball.set_angular_velocity(Vector(randint(-5000, 5000),randint(-5000, 5000),randint(-5000, 5000)))