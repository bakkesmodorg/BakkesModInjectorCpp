from bakkesmod import Vector, Rotator
import math
from random import randint, choice

def vector_to_rotator(v):
	rot = Rotator()
	rot.yaw = math.atan2(v.y, v.x) * 10430.3783504704527
	rot.pitch = math.atan2(v.z, math.sqrt((v.x*v.x) + (v.y * v.y))) * 10430.3783504704527
	rot.roll = 0
	return rot
ball_velocity = Vector(0)

if game_wrapper.is_in_tutorial():
	tut = game_wrapper.get_game_event_as_tutorial()
	player = tut.get_game_car()
	ball = tut.get_ball()

	player_start = Vector(randint(-3000, 3300), randint(600, 3000), 65)
	player_start_rot = Rotator(0, randint(-32000, 32000), 0)
	player.stop()
	player.set_location(player_start)
	player.set_rotation(player_start_rot)
	
	ball_start = Vector(randint(-3000, 3300), -randint(600, 3000), randint(100, 1500))
	ball.stop()
	ball.set_location(ball_start)
	
	#player_start_rot.yaw -= 32000
	#player_start_rot.Roll = 0
	behind = bakpy.rotator_to_vector(player_start_rot)
	
	behind.normalize()
	player_awkward_spot = player_start - behind * Vector(randint(400, 600), randint(500, 800), randint(0, 200))
	player.set_velocity(behind * Vector(800, 800, 0))
	
	ball_velocity = tut.generate_shot(ball_start, player_awkward_spot, randint(700, 1000))
	
	
	bakpy.set_timeout("shoot_ball", .3)
	
def shoot_ball():
	ball.set_velocity(ball_velocity)