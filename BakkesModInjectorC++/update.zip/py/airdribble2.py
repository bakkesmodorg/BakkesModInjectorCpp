from bakkesmod import Vector, Rotator
import math
from random import randint, choice

def vector_to_rotator(v):
	rot = Rotator()
	rot.yaw = math.atan2(v.y, v.x) * 10430.3783504704527
	rot.pitch = math.atan2(v.z, math.sqrt((v.x*v.x) + (v.y * v.y))) * 10430.3783504704527
	rot.roll = 0
	return rot
if game_wrapper.is_in_tutorial():
	tut = game_wrapper.get_game_event_as_tutorial()
	player = tut.get_game_car()
	ball = tut.get_ball()

	random_spawn_loc = Vector(randint(-3800, 3800), randint(-4500, 4500), 35)
	goal_no = 0 if random_spawn_loc.y > 0 else 1 #determine which goal
	ball_dest = tut.generate_goal_aim_location(goal_no, random_spawn_loc)
	face_vec = ball_dest - random_spawn_loc
	face_vec.normalize()
	player_rot = vector_to_rotator(face_vec)

	player.stop()
	player.set_location(random_spawn_loc)
	player.set_rotation(player_rot)
	player.set_velocity(Vector(500, 500, 0) * face_vec)

	ball_loc = random_spawn_loc + Vector(250)*face_vec + Vector(0, 0, 53)
	ball.stop()
	ball.set_location(ball_loc)
	#randint(*(choice([(-900, -500), (300, 500)])))
	ball_velocity = Vector(600)*face_vec + Vector(0, 0, 300)

	bakpy.set_timeout("shoot_ball", .11)
	
def shoot_ball():
	ball.set_velocity(ball_velocity)