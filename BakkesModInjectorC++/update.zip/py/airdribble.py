from bakkesmod import Vector, Rotator
import math


def vector_to_rotator(v):
	rot = Rotator()
	rot.yaw = math.atan2(v.y, v.x) * 10430.3783504704527
	rot.pitch = math.atan2(v.z, math.sqrt((v.x*v.x) + (v.y * v.y))) * 10430.3783504704527
	rot.roll = 0
	return rot
	
	
	
tut = game_wrapper.get_game_event_as_tutorial()

player = tut.get_game_car()
ball = tut.get_ball()
player_loc = player.get_location()
ball_loc = ball.get_location()

dist_to_ball = 400
if ball_loc.y > 0:
	dist_to_ball = -dist_to_ball
	
dest_location = Vector(ball_loc.x - 50, ball_loc.y - dist_to_ball, 40)

new_rot_norm = ball_loc - dest_location 
new_rot_norm.normalize()
new_rot = vector_to_rotator(new_rot_norm)
new_rot.pitch = 0 #Just want yaw
new_rot_norm.z = 0
player.stop()

player.set_location(dest_location)
player.set_rotation(new_rot)
player.set_velocity(Vector(400) * new_rot_norm)

ball.stop()
ball.set_location(Vector(ball_loc.x, ball_loc.y, 100))

new_ball_vel = Vector(500, 500, 0) * new_rot_norm
new_ball_vel.z = 400
ball.set_velocity(new_ball_vel)
#shot = tut.generate_shot(ball.get_location(), player.get_location(), 1300)
