from bakkesmod import Vector, Rotator
import math
from random import randint, choice

def vector_to_rotator(v):
	rot = Rotator()
	rot.yaw = math.atan2(v.y, v.x) * 10430.3783504704527
	rot.pitch = math.atan2(v.z, math.sqrt((v.x*v.x) + (v.y * v.y))) * 10430.3783504704527
	rot.roll = 0
	return rot
	
if game_wrapper.is_in_tutorial():
	tut = game_wrapper.get_game_event_as_tutorial()
	player = tut.get_game_car()
	ball = tut.get_ball()

	#x_start = randint(-1500, 1500) if randint(0, 1) is 1 else -randint(500, 1200)
	ball_spawn = Vector(randint(-1500, 1500), randint(-1700, 1700), 95)
	ball_spawn_norm = Vector(ball_spawn.x, ball_spawn.y, ball_spawn.z)
	ball_spawn_norm.normalize()
	
	#ball_spawn_norm*Vector(randint(300, 800), randint(300, 800), 0)
	car_spawn = ball_spawn - Vector(randint(300, 800), randint(300, 800), 65)
	
	ball.stop()
	player.stop()
	ball.set_location(ball_spawn)
	player.set_location(car_spawn)
	
	dist_to_ball = (ball_spawn - car_spawn)
	dist_to_ball.normalize()
	car_rot = vector_to_rotator(dist_to_ball)
	car_rot.yaw = car_rot.yaw + randint(-5000, 5000)
	
	player.set_rotation(car_rot)
	
	velocity = Vector(randint(700, 1400), randint(700, 1400), 0)
	
	ball.set_velocity(velocity)
	player.set_velocity(velocity)
	
def shoot_ball():
	ball.set_velocity(ball_velocity)