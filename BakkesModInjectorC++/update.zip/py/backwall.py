from bakkesmod import Vector, Rotator
import math
from random import randint, choice

def vector_to_rotator(v):
	rot = Rotator()
	rot.yaw = math.atan2(v.y, v.x) * 10430.3783504704527
	rot.pitch = math.atan2(v.z, math.sqrt((v.x*v.x) + (v.y * v.y))) * 10430.3783504704527
	rot.roll = 0
	return rot
	
if game_wrapper.is_in_tutorial():
	tut = game_wrapper.get_game_event_as_tutorial()
	player = tut.get_game_car()
	ball = tut.get_ball()

	ball_spawn = Vector(randint(-3261, 713), randint(-0, 2566), randint(18, 600))

	car_spawn = Vector(randint(-3777, -837), randint(-3891, -2946), 25)
	car_spawn_rotation = Rotator(-100, randint(-23600, -9475), 0)
	ball.stop()
	player.stop()

	
	end_location = Vector(randint(-3756, -983), randint(-5500, -4262), randint(600, 1900))
	
	if randint(0, 1) == 1:
		car_spawn.x = -car_spawn.x
		ball_spawn.x = -ball_spawn.x
		end_location.x = -end_location.x
		
	ball.set_location(ball_spawn)
	player.set_location(car_spawn)
	player.set_rotation(car_spawn_rotation)
	velocity = tut.generate_shot(ball_spawn, end_location, randint(600, 1100))
	ball.set_velocity(velocity)
	#player.set_velocity(Vector)
	
def shoot_ball():
	ball.set_velocity(ball_velocity)