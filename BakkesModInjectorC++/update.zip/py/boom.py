import bakkesmod
import time
tut = game_wrapper.get_game_event_as_tutorial()

player = tut.get_game_car()
ball = tut.get_ball()
shot = tut.generate_shot(ball.get_location(), player.get_location(), 1300)

bakkesmod.Plugin.set_timeout("shootie", 900)

def shootie():
	ball.set_velocity(shot)
	console.log_to_chatbox("VEL X: " + str(shot.x) + ", Y:" + str(shot.y) + ", Z:" + str(shot.z))